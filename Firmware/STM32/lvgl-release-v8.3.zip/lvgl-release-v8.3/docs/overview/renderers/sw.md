# Software renderer

TODO

